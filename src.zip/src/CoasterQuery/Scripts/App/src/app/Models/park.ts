export class Park{
  ParkID:number;
  Name:string;
  Address:string;
  City:string;
  Zip:string;
  Country:string;
  State:string;
  Note:string;
  IsApproved:boolean;
  IsDefunct:boolean;
  Website:string;
}
