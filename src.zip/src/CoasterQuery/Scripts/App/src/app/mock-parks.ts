import { Park } from './Models/park';
export const ParksMock: Park[] = [
  {ParkID:1,
  Address:"123 fake stree",
  City:"Fake City",
  Country:"USA",
  IsApproved:true,
  IsDefunct:false,
  Name:"Paul's Park",
  Note:"blah blah blah",
  State:"MN",
  Website:"http://google.com",
  Zip:"12345"}
];
